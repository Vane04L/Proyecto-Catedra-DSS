<!doctype html>
<html lang="ES">
<?php
date_default_timezone_set('America/El_Salvador');
$ruta_bdd = '../BDD/';
$ruta_basica = '../Funciones/';
include_once '' . $ruta_bdd . 'conexion.php';
include_once '' . $ruta_bdd . 'datos_nuevos.php';
include_once '' . $ruta_basica . 'funciones_basicas.php';
include_once '' . $ruta_basica . 'funciones_seccion.php';
include_once '' . $ruta_basica . 'funciones_transacciones.php';


?>

<head>
    <title>LOGIN</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
    <link rel="stylesheet" href="../css/style.css">
</head>
<?php


activar_seccion();
$codigo_usuario = $_SESSION['Identificacion_CU'];
$dinero = $_SESSION['Dinero_cu'];
$id_usuario = $_SESSION['id_cuenta_CU'];

$mensaje = '0';

$cantidad = isset($_POST['cantidad']) ? $_POST['cantidad'] : "";
$fecha = isset($_POST['fecha']) ? $_POST['fecha'] : "";
$detinatario = isset($_POST['detinatario']) ? $_POST['detinatario'] : "";

// echo $cantidad . $fecha . $detinatario;
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['transferencia'])) {

    $num_str = 3;

    $sql = 'SELECT dinero_CU FROM cuenta WHERE cuenta.id_cuenta_CU = "'.$id_usuario.'"';
    $dinero_bdd = consultar_dinero($mysqli, $sql);
    if($cantidad <= $dinero_bdd){
        if ($detinatario != 0) {
            $sql = "INSERT INTO `lista_movimiento` (`id_cuenta_CU`, `Cantidad_LIMO`, `Fecha_LIMO`, `Destinatario_CU`, `Transacción_LIMO`, `Comision_LIMO`) 
        VALUES ('" . $id_usuario . "', '" . $cantidad . "', '" . $fecha . "', '" . $detinatario . "', '" . $num_str . "', '0');";
            $consulta_insert = insertar_movimiento($mysqli, $sql);
    
            if($consulta_insert){
                $sql = "UPDATE cuenta SET dinero_CU = dinero_CU - ".$cantidad." WHERE cuenta.id_cuenta_CU = ".$id_usuario.";";
                restar_dinero($mysqli, $sql);
                $mensaje = 3;
            }
            // echo $sql;
        }else{$mensaje = 2;}
    }else{
        $mensaje = 1;
    }

    
}
//echo $codigo_usuario;
switch ($mensaje) {
    case 1:
        $mensaje = "No se pudo realizar la transaccion por falta de fondos, Fondos actuales $".$dinero_bdd;
        break;
    case 2:
        $mensaje = "Debe elegir un usuario destinatario"; 
        break;
    case 3:
        $mensaje = "TRANSACCION REALIZADA CON EXITO";
        break;
    default:
        $mensaje = "";
        break;
}

?>

<body>
    <section class="pt-5 pb-5 mt-0 align-items-center d-flex" style="min-height: 100vh;">
        <div class="container-fluid">

            <div class="row  justify-content-center align-items-center d-flex-row text-center h-100">
                <div class="col-12 col-md-8 col-lg-8 h-50 ">
                    <div class="card shadow fondo_02">
                        <div class="container-fluid">
                            <h4 class="card-title mt-3 text-center">PERFIL</h4>
                            <div class="row">
                                <div class="col-md-3 izquierda"><b>Nombre:</b></div>
                                <div class="col-md-3 izquierda"><?php echo $_SESSION['Nombre_US'] ?></div>
                                <div class="col-md-3 derecha"><b>Fecha:</b></div>
                                <div class="col-md-3 derecha"><?php echo date('Y-m-d H:i:s'); ?></div>
                            </div>
                            <div class="row justify-content-start">
                                <div class="col-md-3 izquierda"><b>DUI:</b></div>
                                <div class="col-md-3 izquierda"><?php echo $_SESSION["DUI_US"] ?></div>
                                <div class="col-md-3 derecha"><b>Identificador:</b></div>
                                <div class="col-md-3 derecha"><?php echo $_SESSION["Identificacion_CU"] ?></div>

                            </div>
                            </br>
                        </div>
                        <a class="btn block-danger text-white" href="../login.php">CERRAR SECCION</a>
                    </div>
                </div>
            </div>
            <br>

            <div class="row  justify-content-center align-items-center d-flex-row text-center h-100">
                <div class="col-12 col-md-8 col-lg-8 h-50 ">
                    <div class="card shadow fondo_01">
                        <div class="container" id="splease-scroll">
                            <h4 class="card-title mt-3 text-center">RETIROS</h4>
                            <div class="container overflow-auto" style="height: 200px;">
                                <a></a>
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th scope="col">#</th>
                                            <th scope="col">Fecha</th>
                                            <th scope="col">cantidad</th>

                                            <th scope="col">comision</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $sql = "SELECT * FROM lista_movimiento LEFT JOIN cuenta ON lista_movimiento.id_cuenta_CU = cuenta.id_cuenta_CU WHERE lista_movimiento.Transacción_LIMO = '1' AND cuenta.Identificacion_CU = '" . $codigo_usuario . "'";
                                        //echo $sql;
                                        consultar_retiros($mysqli, $sql, '4');
                                        ?>
                                    </tbody>
                                </table>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
            <br>

            <div class="row  justify-content-center align-items-center d-flex-row text-center h-100">
                <div class="col-12 col-md-8 col-lg-8 h-50 ">
                    <div class="card shadow fondo_01">
                        <div class="container" id="splease-scroll">
                            <h4 class="card-title mt-3 text-center">DEPOSITO</h4>
                            <div class="container overflow-auto" style="height: 200px;">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th scope="col">#</th>
                                            <th scope="col">Fecha</th>
                                            <th scope="col">cantidad</th>
                                            <th scope="col">comision</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $sql = "SELECT * FROM lista_movimiento LEFT JOIN cuenta ON lista_movimiento.id_cuenta_CU = cuenta.id_cuenta_CU WHERE lista_movimiento.Transacción_LIMO = '2' AND cuenta.Identificacion_CU = '" . $codigo_usuario . "'";
                                        consultar_retiros($mysqli, $sql, '4');
                                        ?>
                                    </tbody>
                                </table>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
            <br>

            <div class="row  justify-content-center align-items-center d-flex-row text-center h-100">
                <div class="col-12 col-md-8 col-lg-8 h-50 ">
                    <div class="card shadow fondo_01">
                        <div class="container" id="splease-scroll">
                            <h4 class="card-title mt-3 text-center">TRANSFERENCIA</h4>
                            
                            <form name="transferencia" method="POST" action="<?php echo $_SERVER['PHP_SELF'] ?>">
                                <!-- <a class="btn btn-success">AGREGAR</a> -->
                                <span class="badge bg-dark"><?php echo $mensaje ?></span>
                                <!-- <input type="hidden" name="dinerito" value="<?php echo $dinero; ?>"> -->
                                <div class="input-group mb-3">
                                    <span class="input-group-text"><i class="bi bi-currency-dollar"></i></span>
                                    <input type="number" min="0.00" step="0.01" class="form-control" placeholder="0.00" id="cantidad" name="cantidad" required>
                                    <span class="input-group-text"><i class="bi bi-calendar2-day"></i></span>
                                    <input class="input-group-text" type="date" id="fecha" name="fecha" required>
                                    <span class="input-group-text"><i class="bi bi-people-fill"></i></span>
                                    <select class="input-group-text" id="detinatario" name="detinatario">
                                        <option value="0" selected>Usuario destinatario</option>
                                        <?php
                                        $sql = 'SELECT * FROM cuenta JOIN usuario ON cuenta.id_usuario_US = usuario.id_US WHERE 1;';
                                        $resultado = mysqli_query($mysqli, $sql);


                                        if (mysqli_num_rows($resultado) > 0) {
                                            while ($row = mysqli_fetch_assoc($resultado)) {
                                                if ($row["Identificacion_CU"] == $codigo_usuario) {
                                                } else {
                                                    echo "<option value='" . $row["id_cuenta_CU"] . "'>" . $row["Identificacion_CU"] . " - " . $row["Nombre_US"] . "</option>";
                                                }
                                            }
                                        }
                                        ?>

                                    </select>
                                    <button class="btn btn-success" type="submit" name="transferencia" id="transferencia">ENVIAR</button>
                                </div>
                            </form>
                            <hr>
                            <div class="container overflow-auto" style="height: 200px;">

                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th scope="col">#</th>
                                            <th scope="col">Fecha</th>
                                            <th scope="col">cantidad</th>
                                            <th scope="col">comision</th>
                                            <th scope="col">destinatario</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $sql = "SELECT * FROM lista_movimiento LEFT JOIN cuenta ON lista_movimiento.id_cuenta_CU = cuenta.id_cuenta_CU WHERE lista_movimiento.Transacción_LIMO = '3' AND cuenta.Identificacion_CU = '" . $_SESSION["Identificacion_CU"] . "'";
                                        // echo $sql;
                                        consultar_retiros($mysqli, $sql, '5');
                                        ?>
                                    </tbody>
                                </table>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
            <br>


        </div>
    </section>
</body>