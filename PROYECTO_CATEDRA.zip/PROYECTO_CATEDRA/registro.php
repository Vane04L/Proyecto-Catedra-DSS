<!doctype html>
<html lang="ES">
<?php
$ruta_bdd = 'BDD/';
$ruta_basica = 'Funciones/';
include_once '' . $ruta_bdd . 'conexion.php';
include_once '' . $ruta_bdd . 'datos_nuevos.php';
include_once '' . $ruta_basica . 'funciones_basicas.php';

// G E T
//Para extraer los datos del arreglo
$nombre_usuario = isset($_GET['nombre']) ? $_GET['nombre'] : "";
$correo_usuario = isset($_GET['correo']) ? $_GET['correo'] : "";
$pass1 = strtoupper(isset($_GET['pass1']) ? $_GET['pass1'] : "");
$pass2 = strtoupper(isset($_GET['pass2']) ? $_GET['pass2'] : "");
$ID = isset($_GET['ID']) ? $_GET['ID'] : "";


if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['registro'])) {

    // P O S T
    // Para extraer los datos que se registraran aqui
    $nombre_usuario = isset($_POST['nombre']) ? $_POST['nombre'] : "";
    $apellido_usuario = isset($_POST['apellido']) ? $_POST['apellido'] : "";
    $correo_usuario = isset($_POST['correo']) ? $_POST['correo'] : "";
    $dui_usuario = isset($_POST['dui']) ? $_POST['dui'] : "";
    $telefono_usuario = isset($_POST['telefono']) ? $_POST['telefono'] : "";
    $empresa_usuario = isset($_POST['empresa']) ? $_POST['empresa'] : "";
    $salario_usuario = isset($_POST['dinero']) ? $_POST['dinero'] : "";
    $password_usuario = isset($_POST['pass']) ? $_POST['pass'] : "";
    $identificador_usuario = isset($_POST['cuenta']) ? $_POST['cuenta'] : "";

    $sql = "INSERT INTO usuario(Correo_US, Nombre_US, Apellidos_US, DUI_US, Telefono_US, Nombre_trabajo_US, Salario_US, Numero_cuentas_US) 
    VALUES ('" . $correo_usuario . "' ,
    '" . $nombre_usuario . "',
    '" . $apellido_usuario . "',
    '" . $dui_usuario . "', 
    '" . $telefono_usuario . "', 
    '" . $empresa_usuario . "', 
    '" . $salario_usuario . "', 
    '1');";

    echo $sql . "<br>";
    $id_usuario = nuevo_usuarios($mysqli, $sql);

    $password_encriptado = encriptar_password($password_usuario);
    // echo 'Registro con exito ID asignada ->' . $id_usuario;

    $sql = "INSERT INTO cuenta(id_usuario_US, Identificacion_CU, Tipo_cuenta_CU, Activa_CU, Password_CU, dinero_CU) 
    VALUES ('" . $id_usuario . "','" . $identificador_usuario . "','1',b'1','" . $password_encriptado . "','00.00')";

    $cumplimiento = nueva_cuenta($mysqli, $sql);

    if ($cumplimiento) {
        header('Location: login.php?registro="true"');
        exit();
    } else {
        echo '<h1 class="text-danger">ERROR</h1>';
    }
}
?>

<head>
    <title>LOGIN</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <section class="pt-5 pb-5 mt-0 align-items-center d-flex" style="min-height: 100vh;">
        <div class="container-fluid">
            <div class="row  justify-content-center align-items-center d-flex-row text-center h-100">
                <!-- SECCION Y PARTE DEL LOGIN -->

                <div class="col-12 col-md-8 col-lg-8 h-50 ">
                    <div class="card shadow fondo_01">
                        <div class="card-body mx-auto">

                            <p class="text-muted font-weight-bold ">
                                <span>COMPLETE EL FORMULARIO PARA TERMINAR DE REGISTRAR</span>
                            </p>

                            <form name="registro" method="POST" action="<?php echo $_SERVER['PHP_SELF'] ?>">


                                <!-- nombre y apellidos -->
                                <div class="input-group mb-3">
                                    <span class="input-group-text color_01">Nombre completo:</span>
                                    <input name="nombre" type="text" class="form-control" value="<?php echo $nombre_usuario; ?>" placeholder="Nombre">
                                    <input name="apellido" type="text" class="form-control" placeholder="Apellidos">
                                </div>

                                <div class="form-group input-group mb-2">
                                    <span class="input-group-text color_01"> <i class="bi bi-envelope-at-fill text-white"></i> </span>
                                    <input name="correo" value="<?php echo $correo_usuario; ?>" class="form-control" placeholder="correo" type="email" required>
                                </div>

                                <div class="input-group mb-2">
                                    <span class="input-group-text color_01"><i class="bi bi-person-vcard-fill text-white"></i> </span>
                                    <input name="dui" class="form-control" placeholder="12345678-0" type="text" pattern="^\d{8}-\d$" required>
                                    <span class="input-group-text color_01"><i class="bi bi-telephone-fill text-white"></i> +503</span>
                                    <input name="telefono" type="text" class="form-control" placeholder="7296 3923" pattern="^\d{4}\s\d{4}$" required>
                                </div>
                                <div class="input-group mb-2">
                                    <span class="input-group-text color_01"><i class="bi bi-briefcase-fill text-white"></i> </span>
                                    <input name="empresa" class="form-control" placeholder="Nombre de la empresa" type="text" required>
                                    <span class="input-group-text color_01"><i class="bi bi-cash-coin text-white"></i>&nbsp;Salario</span>
                                    <input name="dinero" type="number" max="5000" min="0" class="form-control" placeholder="300" pattern="^\d{4}\s\d{4}$" required>
                                </div>

                                <div class="form-group input-group">
                                    <span class="input-group-text"><i class="bi bi-lock-fill color_01"></i> </span>
                                    <input name="pass" class="form-control" value="<?php echo $pass1; ?>" placeholder="Error no contraseña" type="password" readonly>
                                    <span class="input-group-text color_01">Contraseña Asinada en el anterior formulario</span>
                                </div>
                                <br>
                                <p class="text-muted font-weight-bold ">
                                    <span>GUARDE LA SIGUIENTE INFORMACIÓN</span></br>
                                    <span class="text-danger">Importante*</span>
                                    <span>Una vez registre se le asignara un identificador a su cuenta que este caso es: </span>
                                </p>
                                <div class="form-group input-group">
                                    <span class="input-group-text"><i class="bi bi-info-square-fill color_01"></i> </span>
                                    <input name="cuenta" class="form-control" value="<?php echo $ID; ?>" placeholder="" type="text" readonly>
                                </div>
                                <p class="text-muted font-weight-bold ">
                                    <span>Tenga en cuenta que son 3 cuentas por usuario</span></br>
                                </p>

                                </br>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-primary btn-block color_01" name="registro" onclick="return mostrarConfirm()"> TERMINAR REGISTRO <i class="bi bi-arrow-right-square-fill"></i></button>

                                </div>
                                </br>
                                <p class="text-center">Ya tienes una cuenta?
                                    <a href="login.php">Inicia sección</a>
                                </p>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

</body>

<script>
    function mostrarConfirm() {
        var confirmacion = confirm("¿Estás seguro de que quieres hacer esto?, \n Recuerda llenar cada campo con su dato correspondiente.");

        if (confirmacion == true) {
            return true;
        } else {
            return false;
        }
    }
</script>