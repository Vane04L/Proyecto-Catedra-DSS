<!doctype html>
<html lang="ES">
<?php
$ruta_bdd = 'BDD/';
$ruta_basica = 'Funciones/';
include_once '' . $ruta_bdd . 'conexion.php';
include_once '' . $ruta_bdd . 'datos_nuevos.php';
include_once '' . $ruta_basica . 'funciones_basicas.php';

// G E T
//Para extraer los datos del arreglo
$correo_usuario = isset($_GET['correo']) ? $_GET['correo'] : "";
$ID = isset($_GET['ID']) ? $_GET['ID'] : "";
$pass1 = strtoupper(isset($_GET['pass1']) ? $_GET['pass1'] : "");


if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['registro'])) {

    // P O S T
    // Para extraer los datos que se registraran aqui

    $correo_usuario = isset($_POST['correo']) ? $_POST['correo'] : "";
    $identificador_usuario = isset($_POST['cuenta']) ? $_POST['cuenta'] : "";
    $password_usuario = isset($_POST['pass']) ? $_POST['pass'] : "";

    $sql = "SELECT * FROM cuenta JOIN usuario ON cuenta.id_usuario_US = usuario.id_US WHERE usuario.Correo_US = '" . $correo_usuario . "';";
    $max_cuenta = consultar_n_cuentas($mysqli, $sql);
    $password_encriptado = encriptar_password($password_usuario);

    $sql = "SELECT id_US FROM usuario WHERE usuario.Correo_US = '".$correo_usuario."';";
    $id_cuenta_user = saber_usuario($mysqli, $sql);

    if ($max_cuenta) {
        $sql = "INSERT INTO cuenta(id_usuario_US, Identificacion_CU, Tipo_cuenta_CU, Activa_CU, Password_CU, dinero_CU) 
        VALUES ('" . $id_cuenta_user . "','" . $identificador_usuario . "','1',b'1','" . $password_encriptado . "','00.00')";

        $cumplimiento = nueva_cuenta($mysqli, $sql);
        header('Location: login.php?registro="true"');
        exit();
    } else {
        echo '<script>alert("' . 'No permitido, Usted tiene 3 cuentas en total' . '");</script>';
        sleep(5);
        header('Location: login.php?error="true"');
        exit();
    }
}
?>

<head>
    <title>LOGIN</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <section class="pt-5 pb-5 mt-0 align-items-center d-flex" style="min-height: 100vh;">
        <div class="container-fluid">
            <div class="row  justify-content-center align-items-center d-flex-row text-center h-100">
                <!-- SECCION Y PARTE DEL LOGIN -->

                <div class="col-12 col-md-8 col-lg-8 h-50 ">
                    <div class="card shadow fondo_01">
                        <div class="card-body mx-auto">

                            <p class="text-muted font-weight-bold ">
                                <span>USUARIO YA REGISTRADO ANTERIORMENTE</span>
                            </p>

                            <form name="registro" method="POST" action="<?php echo $_SERVER['PHP_SELF'] ?>">


                                <!-- nombre y apellidos -->
                                <p class="text-muted font-weight-bold ">
                                    <span class="text-danger">Importante*</span>
                                    <span>GUARDE LA SIGUIENTE INFORMACIÓN DE LA OTRA NUEVA CUENTA</span></br>

                                </p>
                                <div class="form-group input-group">
                                    <input name="correo" value="<?php echo $correo_usuario; ?>" class="form-control" placeholder="correo" type="hidden">
                                    <input name="pass" class="form-control" value="<?php echo $pass1; ?>" placeholder="Error no contraseña" type="hidden">
                                    <span class="input-group-text"><i class="bi bi-info-square-fill color_01"></i> </span>
                                    <input name="cuenta" class="form-control" value="<?php echo $ID; ?>" placeholder="" type="text" readonly>
                                </div>
                                <p class="text-muted font-weight-bold ">
                                    <span>Recordatorio que son 3 cuentas por usuario</span></br>
                                </p>

                                </br>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-primary btn-block color_01" name="registro" onclick="return mostrarConfirm()"> TERMINAR REGISTRO <i class="bi bi-arrow-right-square-fill"></i></button>
                                </div>
                                </br>
                                <p class="text-center">Ya tienes una cuenta?
                                    <a href="login.php">Inicia sección</a>
                                </p>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

</body>

<script>
    function mostrarConfirm() {
        var confirmacion = confirm("¿Estás seguro de que quieres hacer esto?, \n Recuerda llenar cada campo con su dato correspondiente.");

        if (confirmacion == true) {
            return true;
        } else {
            return false;
        }
    }
</script>