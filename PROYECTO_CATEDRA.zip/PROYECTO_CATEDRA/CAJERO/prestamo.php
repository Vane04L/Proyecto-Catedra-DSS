<!DOCTYPE html>
<html>
<?php
date_default_timezone_set('America/El_Salvador');
$ruta_bdd = '../BDD/';
$ruta_basica = '../Funciones/';
include_once '' . $ruta_bdd . 'conexion.php';
include_once '' . $ruta_bdd . 'datos_nuevos.php';
include_once '' . $ruta_basica . 'funciones_basicas.php';
include_once '' . $ruta_basica . 'funciones_seccion.php';
include_once '' . $ruta_basica . 'funciones_transacciones.php';
include_once '' . $ruta_basica . 'funciones_prestamo.php';

activar_seccion();

if (isset($_SESSION['id_US']) && !empty($_SESSION['id_US'])) {
} else {
    estado_seccion_dependientes();
}



$cantidad = 0;
$resultado_dinero = false;

$dinero = isset($_GET['dinero']) ? $_GET['dinero'] : "0";
$cuenta = isset($_GET['cuenta']) ? $_GET['cuenta'] : "";
$idcu = isset($_GET['idcu']) ? $_GET['idcu'] : "";

$prestamo_max = '5000';
$prestamo_porcentaje = '0.002';
$cuota = $dinero * 0.30;

switch ($dinero) {
    case ($dinero <= 365):
        $prestamo_max = 10000.00;
        $prestamo_porcentaje = 0.03;
        break;
    case ($dinero <= 600):
        $prestamo_max = 25000.00;
        $prestamo_porcentaje = 0.03;
        break;
    case ($dinero <= 900):
        $prestamo_max = 35000.00;
        $prestamo_porcentaje = 0.04;
        break;
    case ($dinero <= 1000):
        $prestamo_max = 50000.00;
        $prestamo_porcentaje = 0.05;
        break;
}



if (isset($cuenta) && !empty($cuenta)) {
    $sql = "UPDATE cuenta SET dinero_CU = dinero_CU - " . $dinero . " WHERE  cuenta.Identificacion_CU = '" . $cuenta . "';";
    // echo $sql;
    $resultado_dinero = restar_dinero($mysqli, $sql);


    if ($resultado_dinero) {
        $fecha_actual = date('Y-m-d');

        $sql = "INSERT INTO `lista_movimiento` (`id_lista_LIMO`, `id_cuenta_CU`, `Cantidad_LIMO`, `Fecha_LIMO`, `Destinatario_CU`, `Transacción_LIMO`, `Comision_LIMO`) 
        VALUES (NULL, '" . $idcu . "', '" . $dinero . "', '" . $fecha_actual . "', NULL, '1', '0');";
        $resultado = mysqli_query($mysqli, $sql);
    }
}

$identificador = isset($_POST['identificador']) ? $_POST['identificador'] : "";
$cantidad_form = isset($_POST['cantidad_form']) ? $_POST['cantidad_form'] : "";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['prestamos'])) {
    $dinerito = isset($_POST['dinerito']) ? $_POST['dinerito'] : "";
    $id_usuario = isset($_POST['id_usuario']) ? $_POST['id_usuario'] : "";


    $cod_usuario = isset($_POST['cod_usuario']) ? $_POST['cod_usuario'] : "";
    $monto = isset($_POST['monto']) ? $_POST['monto'] : "";
    $cuota = isset($_POST['cuota']) ? $_POST['cuota'] : "";
    $interes = isset($_POST['interes']) ? $_POST['interes'] : "";
    $plazo = isset($_POST['plazo']) ? $_POST['plazo'] : "";

    $sql = "INSERT INTO `prestamo` (`id_prestamo_PR`, `usuario_CU`, `Monto_PR`, `Estado_PR`, `cuota_PR`, `PLazo_PR`, `Taza_interes_PR`) 
    VALUES ('', '" . $id_usuario . "', '" . $monto . "', NULL, '" . $cuota . "', '" . $interes . "', '" . $plazo . "');";
    insertar_prestamo($mysqli, $sql);
    // echo $dinerito . ' --- ' . $cod_usuario . ' --- ' . $monto . ' --- ' . $cuota . ' --- ' . $interes . ' --- ' . $plazo;
}
?>

<head>
    <!-- Incluye los estilos de Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
    <link rel="stylesheet" href="../css/style.css">

</head>

<body class="empleado">

    </br>
    <div class="tituloEmpleado text-white">
        <i class="bi bi-briefcase-fill"></i> AGREGANDO PRESTAMO | <?php echo $_SESSION['Nombre_trabajo_US'] ?>
    </div>
    <div class="container mt-5 vidrio border">
        <!-- Recordatorio = agregar una 4ta pestañas -->

        <div class="tab-content" id="myTabContent">
            <ul class="nav nav-tabs" id="myTab" role="tablist">
                <li class="nav-item">
                    <a class="nav-link active" id="tab2" data-toggle="tab" href="#panel2" role="tab" aria-controls="panel2" aria-selected="true">RETIROS</a>
                </li>
                <li>
                    <a class="nav-link text-dark" href="index.php">CERRAR SECCION</a>
                </li>
            </ul>
            <div class="tab-pane show active" id="panel2" role="tabpanel" aria-labelledby="tab2">
                <div>
                    <hr>
                    <h1>Empleado <?php echo $_SESSION['Nombre_US'] . ' ' . $_SESSION['Apellidos_US'] ?></h1>


                    <hr>
                    <div class="row">
                        <div class="col-7">
                            <ol class="list-group list-group-numbered">
                                <li class="list-group-item d-flex justify-content-between align-items-start">
                                    <div class="ms-2 me-auto">
                                        <div class="fw-bold">NUMERO DE CUENTAS</div>
                                        <table class="table">
                                            <thead>
                                                <tr>
                                                    <th scope="col">CUENTA</th>
                                                    <th scope="col">USUARIO</th>
                                                    <th scope="col">SALARIO</th>
                                                    <th scope="col">OPCIONES</th>
                                                </tr>
                                            </thead>
                                            <tbody>

                                                <?php
                                                $sql = 'SELECT * FROM cuenta JOIN usuario ON cuenta.id_usuario_US = usuario.id_US WHERE cuenta.Tipo_cuenta_CU = "1"';
                                                $resultado = mysqli_query($mysqli, $sql);
                                                $cantidad = mysqli_num_rows($resultado);

                                                if (mysqli_num_rows($resultado) > 0) {
                                                    while ($row = mysqli_fetch_assoc($resultado)) {
                                                        echo '<tr>';
                                                        echo '<td>' . $row['Identificacion_CU'] . '</td>';
                                                        echo '<td>' . $row['Correo_US'] . '</td>';
                                                        echo '<td>$' . $row['Salario_US'] . '.00</td>';
                                                        echo '<td><a href="prestamo.php?dinero=' . $row['Salario_US'] . '&cuenta=' . $row['Identificacion_CU'] . '&idcu=' . $row['id_cuenta_CU'] . '" class="btn btn-dark btn-sm">Seleccionar</a></td>';
                                                        echo '</tr>';
                                                    }
                                                } else {
                                                    echo '<td colspan="3">NO HAY USUARIO REGISTRADOS</td>';
                                                }
                                                ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <span class="badge bg-dark rounded-pill"><?php echo $cantidad ?></span>
                                </li>

                            </ol>
                        </div>
                        <div class="col">
                            <div class="container">
                                <form name="prestamos" method="POST" action="<?php echo $_SERVER['PHP_SELF'] ?>">
                                    <!-- <a class="btn btn-success">AGREGAR</a> -->
                                    <input type="hidden" name="dinerito" id="dinerito" value="<?php echo $dinero; ?>">
                                    <input type="hidden" name="id_usuario" id="id_usuario" value="<?php echo $idcu; ?>">

                                    <div class="input-group mb-3">
                                        <span class="input-group-text bg bg-dark text-white"><i class="bi bi-currency-dollar"></i></span>
                                        <input type="text" class="form-control" placeholder="BAS-0000-0000" id="cod_usuario" name="cod_usuario" value="<?php echo $cuenta ?>" required>
                                        <span class="input-group-text bg bg-dark text-white">CUOTA MAX $<?php echo $cuota ?>.00</span>
                                        <input type="number" min="0.00" max="<?php echo $cuota ?>.00" step="0.01" class="form-control" placeholder="0.00" id="cuota" name="cuota" value="" required>

                                    </div>
                                    <div class="input-group mb-3">
                                        <span class="input-group-text  bg bg-dark text-white">PRESTAMO MAX $<?php echo $prestamo_max ?>.00</span>
                                        <input type="number" min="0.00" max="<?php echo $prestamo_max ?>.00" step="0.01" class="form-control" placeholder="0.00" id="monto" onchange="hacer_calculo()" name="monto" required>

                                    </div>
                                    <div class="input-group mb-3">
                                        <span class="input-group-text bg bg-dark text-white">%</span>
                                        <input type="number" class="form-control" placeholder="0" id="interes" name="interes" value="<?php echo $prestamo_porcentaje; ?>" readonly required>
                                        <span class="input-group-text bg bg-dark text-white">Años</span>
                                        <input type="number" step="0.01" class="form-control" placeholder="0" id="plazo" name="plazo" readonly required>

                                    </div>

                                    <button class="btn btn-dark" type="submit" name="prestamos" id="prestamos">CREAR PRESTAMO</button>

                                </form>
                            </div>

                        </div>
                    </div>

                </div>
            </div>

        </div>
        <hr>
        <div class="container">
            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">CUENTA</th>
                        <th scope="col">PRESTAMO</th>
                        <th scope="col">CUOTA</th>
                        <th scope="col">PLAZO</th>
                        <th scope="col">ESTADO</th>
                        <th scope="col">OPCIONES</th>
                    </tr>
                </thead>
                <tbody>

                    <?php
                    $sql = 'SELECT * FROM prestamo JOIN cuenta ON prestamo.usuario_CU = cuenta.id_cuenta_CU WHERE 1';
                    $resultado = mysqli_query($mysqli, $sql);
                    $cantidad = mysqli_num_rows($resultado);

                    if (mysqli_num_rows($resultado) > 0) {
                        while ($row = mysqli_fetch_assoc($resultado)) {
                            echo '<tr>';
                            echo '<td>' . $row['Identificacion_CU'] . '</td>';
                            echo '<td>' . $row['Monto_PR'] . '</td>';
                            echo '<td>' . $row['cuota_PR'] . '</td>';
                            echo '<td>' . $row['PLazo_PR'] . '</td>';
                            if ($row['Estado_PR'] == '1') {
                                echo '<td>ACTIVO</td>';
                            } else {
                                if ($row['Estado_PR'] == '0') {
                                    echo '<td>RECHAZADO</td>';
                                } else {
                                    echo '<td>EN ESPERA</td>';
                                }
                            }
                            // echo '<td>' . $row['Estado_PR'] . '</td>';

                            if ($row['Estado_PR'] == '') {
                                echo '<td><a href="presta_id.php?estado=1&id=' . $row['id_prestamo_PR'] . '" class="btn btn-success btn-sm">ACEPTAR</a>';
                                echo '<a href="presta_id.php?estado=0&id=' . $row['id_prestamo_PR'] . '" class="btn btn-danger btn-sm">DENEGAR</a></td>';
                            }else{
                                echo '<td></td>';
                            }

                            echo '</tr>';
                        }
                    } else {
                        echo '<td colspan="3">NO HAY PRESTAMOS</td>';
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>

    </br>
    </br>
    <!-- Incluye los scripts de Bootstrap -->
</body>

</html>

<script>
    function hacer_calculo() {

        // const salarioCliente = document.getElementById("dinerito").value;
        // const montoPrestamo = 
        // const interesAnual = document.getElementById("interes").value;
        // const cuotaMensual = document.getElementById("cuota").value;

        // const nombreCliente = "Jose";
        function calcularTiempoParaPagar(prestamo, tasa_interes, pago_mensual) {
            const num_pagos = Math.log(1 + (prestamo * tasa_interes) / pago_mensual) / Math.log(1 + tasa_interes);
            const num_anos = num_pagos / 12;
            return num_anos;
        }

        // Ejemplo de uso:
        const prestamo = document.getElementById("monto").value;; // $10,000
        const tasa_interes = document.getElementById("interes").value;; // 5%
        const pago_mensual = document.getElementById("cuota").value;; // $200
        const num_anos = calcularTiempoParaPagar(prestamo, tasa_interes, pago_mensual);
        // console.log(`El préstamo tardará ${num_anos} años en ser pagado.`);


        // console.log(`${nombreCliente} tardará aproximadamente ${tiempoEnAnos.toFixed(2)} años en pagar el préstamo.`);

        // console.log("El tiempo necesario para pagar el préstamo es de " + tiempo + " meses.");
        document.getElementById("plazo").value = num_anos.toFixed(3);
    }
</script>