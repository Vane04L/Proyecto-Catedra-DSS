<!doctype html>
<html lang="ES">
<?php
$ruta_bdd = '../BDD/';
$ruta_basica = '../Funciones/';
include_once '' . $ruta_bdd . 'conexion.php';
include_once '' . $ruta_bdd . 'datos_nuevos.php';
include_once '' . $ruta_basica . 'funciones_basicas.php';

?>

<head>
    <title>LOGIN</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
    <link rel="stylesheet" href="../css/style.css">
</head>
<?php
$nombre_usuario = isset($_POST['nombre']) ? $_POST['nombre'] : "";
$correo_usuario = isset($_POST['correo']) ? $_POST['correo'] : "";

$pass1 = strtoupper(isset($_POST['pass1']) ? $_POST['pass1'] : "");
$pass2 = strtoupper(isset($_POST['pass2']) ? $_POST['pass2'] : "");
$tipo = isset($_POST['tipo']) ? $_POST['tipo'] : "";


$error = true;

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['registro'])) {
    //echo $nombre_usuario . $correo_usuario . $pass1 . $pass2;
    if (strcasecmp($pass1, $pass2) == 0) {
        $consulta = "SELECT * FROM usuario WHERE usuario.Correo_US = '" . $correo_usuario . "'";
        //echo $consulta . '<br>';

        $usuario_registrado = false;
        $usuario_registrado = existe_registro($mysqli, $consulta);

        $numero_aleatorio1 = rand(100, 999) . rand(0, 9);
        $numero_aleatorio2 = rand(100, 999) . rand(0, 9);
        $numero_aleatorio = 'BAS-' . $numero_aleatorio1 . '-' . $numero_aleatorio2;

        $usuario_string = http_build_query(
            array(
                'nombre' => $nombre_usuario,
                'correo' => $correo_usuario,
                'pass1' => $pass1,
                'pass2' => $pass2,
                'ID' => $numero_aleatorio,
                'tipo' => $tipo
            )
        );

        $usuario_string_cuenta = http_build_query(
            array(
                'correo' => $correo_usuario,
                'pass1' => $pass1,
                'ID' => $numero_aleatorio
            )
        );

        if ($usuario_registrado) {
            header('Location: nueva_cuenta.php?' . $usuario_string_cuenta);
            echo 'Funciona esta mamada?';
        } else {
            header('Location: registro.php?' . $usuario_string);
            exit();
        }
        // Redirige al usuario a otra página con la cadena de consulta en la URL

    } else {
        echo '<script>alert("' . 'Error, La contraseña no coincide' . '");</script>';
        $error = false;
    }
}
?>

<body class="empleado">
    <section class="pt-5 pb-5 mt-0 align-items-center d-flex" style="min-height: 100vh;">
        <div class="container-fluid">
            <div class="row  justify-content-center align-items-center d-flex-row text-center h-100">
                <div class="col-12 col-md-4 col-lg-3 h-50 ">
                    <div class="card shadow fondo_01">
                        <div class="card-body mx-auto">
                            <h4 class="card-title mt-3 text-center">BIENVENIDO EMPLEADO</h4>

                            <p class="text-muted font-weight-bold ">
                                <span>REGISTRAR USUARIO</span>
                            </p>
                            <form name="registro" method="POST" action="<?php echo $_SERVER['PHP_SELF'] ?>">
                                <div class="form-group input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text"><i class="bi bi-person-fill color_03"></i></span>
                                    </div>
                                    <input name="nombre" value="<?php echo $nombre_usuario; ?>" class="form-control" placeholder="Nombre" type="text" required>
                                </div>

                                <div class="form-group input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text"> <i class="bi bi-envelope-at-fill color_03"></i> </span>
                                    </div>
                                    <input name="correo" value="<?php echo $correo_usuario; ?>" class="form-control" placeholder="correo" type="email" required>
                                </div>
                                <div class="form-group input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text"> <i class="bi bi-person-check color_03"></i> </span>
                                    </div>
                                    <select class="form-control" name="tipo">
                                        <option value="1">Cliente</option>
                                        <option value="2">Dependiente</option>
                                        <option value="3">Empleado</option>
                                    </select>
                                </div>
                                </br>
                                <?php
                                if ($error) {
                                    echo '<p class="text-muted"><span> Asigne contraseña</span></p>';
                                } else {
                                    echo '<p class="text-danger"><span><i class="bi bi-exclamation-diamond-fill"></i> Contraseña no coinciden</span></p>';
                                }
                                ?>
                                <div class="form-group input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text"><i class="bi bi-lock-fill color_03"></i> </span>
                                    </div>
                                    <input name="pass1" class="form-control" placeholder="Crea una contraseña" type="password" maxlength="16" minlength="8" required>
                                </div>

                                <div class="form-group input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text"><i class="bi bi-lock-fill color_03"></i> </span>
                                    </div>
                                    <input name="pass2" class="form-control" placeholder="Repetir contraseña" type="password" maxlength="16" minlength="8" required>
                                </div>
                                </br>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-primary btn-block color_03" name="registro"> SEGUIR CON EL REGISTRO <i class="bi bi-arrow-right-square-fill"></i></button>
                                </div>
                                <hr>
                                <div class="form-group">
                                    <a href="prestamo.php" class="btn btn-default btn-block color_03" name="registro"> CREAR PRESTAMO <i class="bi bi-arrow-right-square-fill"></i></a>
                                </div>
                                </br>

                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
</body>
<?php

?>

</html>