<?php
date_default_timezone_set('America/El_Salvador');
$ruta_bdd = '../BDD/';
$ruta_basica = '../Funciones/';
include_once '' . $ruta_bdd . 'conexion.php';
include_once '' . $ruta_bdd . 'datos_nuevos.php';
include_once '' . $ruta_basica . 'funciones_basicas.php';
include_once '' . $ruta_basica . 'funciones_seccion.php';
include_once '' . $ruta_basica . 'funciones_transacciones.php';
include_once '' . $ruta_basica . 'funciones_prestamo.php';

$estado = isset($_GET['estado']) ? $_GET['estado'] : "";
$id = isset($_GET['id']) ? $_GET['id'] : "";


    $sql = "UPDATE `prestamo` SET `Estado_PR` = b'".$estado."' WHERE `prestamo`.`id_prestamo_PR` = ".$id.";";
    if (mysqli_query($mysqli, $sql)) {
        echo "Registro insertado correctamente";
        $confirmacion = true;
        header('Location: prestamo.php');
    } else {
        echo "Error al insertar registro: " . mysqli_error($mysqli);
    }

?>