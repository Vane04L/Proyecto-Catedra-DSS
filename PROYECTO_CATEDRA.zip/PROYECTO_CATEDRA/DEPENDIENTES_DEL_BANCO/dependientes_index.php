<!DOCTYPE html>
<html>
<?php
date_default_timezone_set('America/El_Salvador');
$ruta_bdd = '../BDD/';
$ruta_basica = '../Funciones/';
include_once '' . $ruta_bdd . 'conexion.php';
include_once '' . $ruta_bdd . 'datos_nuevos.php';
include_once '' . $ruta_basica . 'funciones_basicas.php';
include_once '' . $ruta_basica . 'funciones_seccion.php';
include_once '' . $ruta_basica . 'funciones_transacciones.php';
include_once '' . $ruta_basica . 'funciones_dependientes.php';

activar_seccion();

if (isset($_SESSION['id_US']) && !empty($_SESSION['id_US'])) {
} else {
    estado_seccion_dependientes();
}



$cantidad = 0;
$resultado_dinero = false;

$dinero = isset($_GET['dinero']) ? $_GET['dinero'] : "";
$cuenta = isset($_GET['cuenta']) ? $_GET['cuenta'] : "";
$idcu = isset($_GET['idcu']) ? $_GET['idcu'] : "";

// 

if (isset($cuenta) && !empty($cuenta)) {
    $sql = "UPDATE cuenta SET dinero_CU = dinero_CU - " . $dinero . " WHERE  cuenta.Identificacion_CU = '" . $cuenta . "';";
    // echo $sql;
    $resultado_dinero = restar_dinero($mysqli, $sql);


    if ($resultado_dinero) {
        $fecha_actual = date('Y-m-d');

        $sql = "INSERT INTO `lista_movimiento` (`id_lista_LIMO`, `id_cuenta_CU`, `Cantidad_LIMO`, `Fecha_LIMO`, `Destinatario_CU`, `Transacción_LIMO`, `Comision_LIMO`) 
        VALUES (NULL, '".$idcu."', '".$dinero."', '".$fecha_actual."', NULL, '1', '0');";
        $resultado = mysqli_query($mysqli, $sql);
    }
}

$identificador = isset($_POST['identificador']) ? $_POST['identificador'] : "";
$cantidad_form = isset($_POST['cantidad_form']) ? $_POST['cantidad_form'] : "";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['retiro'])) {
}
?>

<head>
    <!-- Incluye los estilos de Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
    <link rel="stylesheet" href="../css/style.css">

</head>

<body class="dependientes">

    </br>
    <div class="titulo text-white">
        <i class="bi bi-briefcase-fill"></i> EMPRESA: <?php echo $_SESSION['Nombre_trabajo_US'] ?>
    </div>
    <div class="container mt-5 vidrio border">
        <!-- Recordatorio = agregar una 4ta pestañas -->

        <div class="tab-content" id="myTabContent">
            <ul class="nav nav-tabs" id="myTab" role="tablist">
                <li class="nav-item">
                    <a class="nav-link active" id="tab2" data-toggle="tab" href="#panel2" role="tab" aria-controls="panel2" aria-selected="true">RETIROS</a>
                </li>
                <li>
                    <a class="nav-link" href="../login.php">CERRAR SECCION</a>
                </li>
            </ul>
            <div class="tab-pane show active" id="panel2" role="tabpanel" aria-labelledby="tab2">
                <div>
                    <hr>
                    <h1><?php echo $_SESSION['Nombre_US'] . ' ' . $_SESSION['Apellidos_US'] ?></h1>
                    <?php
                    if ($resultado_dinero) {
                        echo '<span class="badge bg-success">SE HA RETIRADO EL DINERO DE LA CUENTA ' . $cuenta . '</span>';
                    }
                    ?>

                    <hr>
                    <div class="row">
                        <div class="col">
                            <ol class="list-group list-group-numbered">
                                <li class="list-group-item d-flex justify-content-between align-items-start">
                                    <div class="ms-2 me-auto">
                                        <div class="fw-bold">NUMERO DE CUENTAS</div>
                                        <table class="table">
                                            <thead>
                                                <tr>
                                                    <th scope="col">CUENTA</th>
                                                    <th scope="col">USUARIO</th>
                                                    <th scope="col">OPCIONES</th>
                                                </tr>
                                            </thead>
                                            <tbody>

                                                <?php
                                                $sql = 'SELECT * FROM cuenta JOIN usuario ON cuenta.id_usuario_US = usuario.id_US WHERE usuario.DUI_US = "' . $identificador . '"';
                                                $resultado = mysqli_query($mysqli, $sql);
                                                $cantidad = mysqli_num_rows($resultado);

                                                if (mysqli_num_rows($resultado) > 0) {
                                                    while ($row = mysqli_fetch_assoc($resultado)) {
                                                        echo '<tr>';
                                                        echo '<td>' . $row['Identificacion_CU'] . '</td>';
                                                        echo '<td>' . $row['Correo_US'] . '</td>';
                                                        echo '<td><a href="dependientes_index.php?dinero=' . $cantidad_form . '&cuenta=' . $row['Identificacion_CU'] . '&idcu=' . $row['id_cuenta_CU'] . '" class="btn btn-primary btn-sm">Seleccionar</a></td>';
                                                        echo '</tr>';
                                                    }
                                                } else {
                                                    echo '<td colspan="3">NO HAY USUARIO REGISTRADO, INGRESE UN NUMERO DE DUI</td>';
                                                }
                                                ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <span class="badge bg-primary rounded-pill"><?php echo $cantidad ?></span>
                                </li>

                            </ol>
                        </div>
                        <div class="col">
                            <div class="container">
                                <form name="retiro" method="POST" action="<?php echo $_SERVER['PHP_SELF'] ?>">
                                    <!-- <a class="btn btn-success">AGREGAR</a> -->

                                    <!-- <input type="hidden" name="dinerito" value="<?php echo $dinero; ?>"> -->
                                    <div class="input-group mb-3">
                                        <span class="input-group-text"><i class="bi bi-person-vcard-fill color_02"></i></span>
                                        <input name="identificador" value="" class="form-control" placeholder="12345678-0" type="text" pattern="^\d{8}-\d$" required>
                                        <span class="input-group-text"><i class="bi bi-currency-dollar color_02"></i></span>
                                        <input type="number" min="0.00" step="0.01" class="form-control" placeholder="0.00" id="cantidad_form" name="cantidad_form" required>
                                        <button class="btn btn-primary" type="submit" name="retiro" id="transferencia">ENVIAR</button>
                                    </div>
                                </form>
                            </div>

                        </div>
                    </div>

                </div>
            </div>

        </div>
        <hr>
    </div>

    </br>
    </br>
    <!-- Incluye los scripts de Bootstrap -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>


</body>

</html>