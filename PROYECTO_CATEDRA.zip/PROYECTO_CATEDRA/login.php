<!doctype html>
<html lang="ES">
<?php
$ruta_bdd = 'BDD/';
$ruta_basica = 'Funciones/';
include_once '' . $ruta_bdd . 'conexion.php';
include_once '' . $ruta_bdd . 'datos_nuevos.php';
include_once '' . $ruta_basica . 'funciones_basicas.php';
include_once '' . $ruta_basica . 'funciones_seccion.php';

desactivar_seccion();

?>

<head>
    <title>LOGIN</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<?php
$error_seccion = true;
$error = false;

$registro = isset($_GET['registro']) ? $_GET['registro'] : "";
$error = isset($_GET['error']) ? $_GET['error'] : "";

$identificador = isset($_POST['identificador']) ? $_POST['identificador'] : "";
$password = strtoupper(isset($_POST['password']) ? $_POST['password'] : "");

if($error){
    echo '<script>alert("' . 'No permitido, Usted tiene 3 cuentas en total' . '");</script>';
}


if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['login'])) {
    $sql = "SELECT * FROM cuenta 
    JOIN usuario ON cuenta.id_usuario_US = usuario.id_US 
    WHERE cuenta.Identificacion_CU = '" . $identificador . "';";

    $seccion_iniciada = iniciar_seccion($mysqli, $sql, $password);

    switch ($seccion_iniciada) {
        case 1:
            echo "Sección 1 iniciada";
            header('Location: CLIENTES_PRESTAMISTA/transacciones.php');
            break;
        case 2:
            $error_seccion = false;
            break;
        default:
            echo "Error de funcion";
            break;
    }
}
?>

<body>
    <section class="pt-5 pb-5 mt-0 align-items-center d-flex" style="min-height: 100vh;">
        <div class="container-fluid">
            <div class="row  justify-content-center align-items-center d-flex-row text-center h-100">
                <div class="col-12 col-md-4 col-lg-3 h-50 ">
                    <div class="card shadow fondo_01">
                        <div class="card-body mx-auto">
                            <h4 class="card-title mt-3 text-center">BIENVENIDO</h4>
                            <p class="text-center"></p>
                            <?php
                            if($error_seccion){
                                if ($registro) {
                                    echo '<p class="text-muted font-weight-bold"> <span><i class="bi bi-person-fill-add color_01"></i> CUENTA REGISTRARDA <i class="bi bi-person-fill-add"></i></span> </p>';
                                } else {
                                    echo '<p class="text-muted font-weight-bold "> <span>REGISTRATE</span> </p>';
                                }
                            }
                            else{
                                echo '<p class="text-danger font-weight-bold"> <span><i class="bi bi-exclamation-triangle-fill"></i> ERROR CREDENCIALES <i class="bi bi-exclamation-triangle-fill"></i></span> </p>';
                            }
                            

                            ?>

                            <form name="login" method="POST" action="<?php echo $_SERVER['PHP_SELF'] ?>">

                                <div class="form-group input-group mb-2">
                                    <span class="input-group-text"><i class="bi bi-upc-scan color_01"></i></i></span>
                                    <input name="identificador" value="" class="form-control" placeholder="BAS-0000-0000" pattern="^BAS-\d{4}-\d{4}$" type="text" required>
                                </div>

                                <div class="form-group input-group">
                                    <span class="input-group-text"><i class="bi bi-file-earmark-lock-fill color_01"></i></span>
                                    <input name="password" value="" class="form-control" placeholder="Contraseña" type="text" required>
                                </div>
                                </br>


                                <div class="form-group">
                                    <button type="submit" class="btn btn-primary btn-block color_01" name="login"> INICIAR SECCION <i class="bi bi-arrow-right-square-fill"></i></button>
                                </div>
                                </br>
                                <p class="text-center">No tienes una cuenta?
                                    <a href="index.php">Registrate (Hasta 3 cuentas maximas)</a>
                                </p>
                                
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</body>
<?php

?>

</html>