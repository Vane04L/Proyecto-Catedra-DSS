<?php

function insertar_movimiento($mysqli, $sql)
{
    $confirmacion = false;
    if (mysqli_query($mysqli, $sql)) {
        echo "Registro insertado correctamente";
        $confirmacion = true;
    } else {
        echo "Error al insertar registro: " . mysqli_error($mysqli);
    }

    return $confirmacion;
}

function restar_dinero($mysqli, $sql)
{
    $confirmacion = false;
    if (mysqli_query($mysqli, $sql)) {
        // echo "Registro insertado correctamente";
        $confirmacion = true;
    } else {
        // echo "Error al insertar registro: " . mysqli_error($mysqli);
    }

    return $confirmacion;
}

function consultar_dinero($mysqli, $sql,)
{
    // echo $sql;
    $resultado = mysqli_query($mysqli, $sql);
    $dinero_user = "0";

    while ($fila = mysqli_fetch_assoc($resultado)) {
        $dinero_user = $fila["dinero_CU"];
    }
    return $dinero_user;
}
