<?php

function activar_seccion() {
    session_start();
}

function desactivar_seccion(){
    session_start();
    if (session_status() === PHP_SESSION_ACTIVE) {
        // La sesión está activa, se puede acceder a las variables de sesión
        session_destroy();
    }
    
}

function estado_seccion(){
    if (session_status() === PHP_SESSION_ACTIVE) {
    }else{
        session_destroy();
        header('Location: login.php');
    }
}

function iniciar_seccion($mysqli, $sql, $password)
{
    $resultado_funcion = 0;
    $resultado = mysqli_query($mysqli, $sql);
    $id_cuenta_cu = '';
    $id_usuario_su = '';
    $identificacion_cu = '';
    $password_cu = '';
    $nombre_us = '';
    $dui_us = '';
    $dinero_cu = '';

    while ($fila = mysqli_fetch_assoc($resultado)) {
        $id_cuenta_cu = $fila["id_cuenta_CU"];
        $id_usuario_su = $fila["id_usuario_US"];
        $identificacion_cu = $fila["Identificacion_CU"];
        $password_cu = $fila["Password_CU"];
        $nombre_us = $fila["Nombre_US"];
        $dui_us = $fila["DUI_US"];
        $dinero_cu = $fila["dinero_CU"];
    }

    if (password_verify($password, $password_cu)) {
        $resultado_funcion = 1;

        session_start();
        $_SESSION['id_cuenta_CU'] = $id_cuenta_cu;
        $_SESSION['id_usuario_su'] = $id_usuario_su;
        $_SESSION['Identificacion_CU'] = $identificacion_cu;
        $_SESSION['Password_CU'] = $password_cu;
        $_SESSION['Nombre_US'] = $nombre_us;
        $_SESSION['DUI_US'] = $dui_us;
        $_SESSION['Dinero_cu'] = $dinero_cu;
    } else {
        $resultado_funcion = 2;
    }

    return $resultado_funcion;
}
