<?php

function encriptar_password($password) {
    $password_encriptado = password_hash($password, PASSWORD_DEFAULT);
    
    return $password_encriptado;
}

function existe_registro($conexion, $sql) {
    $Hay_registro = false;
    $resultado = mysqli_query($conexion, $sql);
    $si = mysqli_num_rows($resultado) > 0;

    if($si){
        $Hay_registro = true;
    }

    return $Hay_registro;
}


?>