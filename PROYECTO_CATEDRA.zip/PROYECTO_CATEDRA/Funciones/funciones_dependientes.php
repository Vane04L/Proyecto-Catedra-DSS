<?php

function estado_seccion_dependientes()
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        session_destroy();
        header('Location: ../index.php');
    }
}

function iniciar_seccion_dependiente($mysqli, $sql)
{
    $resultado_funcion = 0;
    $resultado = mysqli_query($mysqli, $sql);
    $id_US = '';
    $Correo_US = '';
    $Nombre_US = '';
    $Apellidos_US = '';
    $DUI_US = '';
    $Telefono_US = '';
    $Nombre_trabajo_US = '';
    $Salario_US = '';
    $Numero_cuentas_US = '';


    while ($fila = mysqli_fetch_assoc($resultado)) {
        $id_US = $fila["id_US"];
        $Correo_US = $fila["Correo_US"];
        $Nombre_US = $fila["Nombre_US"];
        $Apellidos_US = $fila["Apellidos_US"];
        $DUI_US = $fila["DUI_US"];
        $Telefono_US = $fila["Telefono_US"];
        $Nombre_trabajo_US = $fila["Nombre_trabajo_US"];
        $Salario_US = $fila["Salario_US"];
        $Numero_cuentas_US = $fila["Numero_cuentas_US"];
    }

    if (mysqli_num_rows($resultado) > 0) {
        $resultado_funcion = 1;

        session_start();
        $_SESSION['id_US'] = $id_US;
        $_SESSION['Correo_US'] = $Correo_US;
        $_SESSION['Nombre_US'] = $Nombre_US;
        $_SESSION['Apellidos_US'] = $Apellidos_US;
        $_SESSION['DUI_US'] = $DUI_US;
        $_SESSION['Telefono_US'] = $Telefono_US;
        $_SESSION['Nombre_trabajo_US'] = $Nombre_trabajo_US;
        $_SESSION['Salario_US'] = $Salario_US;
        $_SESSION['Numero_cuentas_US'] = $Numero_cuentas_US;
    } else {
        $resultado_funcion = 2;
    }

    return $resultado_funcion;
}
