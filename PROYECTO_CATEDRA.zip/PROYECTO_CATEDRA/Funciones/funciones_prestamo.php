<?php

function insertar_prestamo($mysqli, $sql)
{
    $confirmacion = false;
    if (mysqli_query($mysqli, $sql)) {
        echo "Registro insertado correctamente";
        $confirmacion = true;
    } else {
        echo "Error al insertar registro: " . mysqli_error($mysqli);
    }

    return $confirmacion;
}
