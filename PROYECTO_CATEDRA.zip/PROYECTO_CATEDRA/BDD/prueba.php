<?php
include_once 'conexion.php';
include_once 'datos_nuevos.php';

$consulta = "SELECT * FROM `usuario` WHERE 1;";

$sql = "INSERT INTO usuario(Correo_US, Nombre_US, Apellidos_US, DUI_US, Telefono_US, Nombre_trabajo_US, Salario_US, Numero_cuentas_US) 
    VALUES ('Jonnathanweltx@gmail.com' ,'Prueba', 'desql', '12345678-0', '71287345', 'Don prueba', '400', '0');";
$id = nuevo_usuarios($mysqli, $sql);
echo '<br>';
echo 'Registro con exito ID asignada ->' . $id;


// $sql = "INSERT INTO usuario(Correo_US, Nombre_US, Apellidos_US, DUI_US, Telefono_US, Nombre_trabajo_US, Salario_US, Numero_cuentas_US) 
//     VALUES ('Jonnathanweltx@gmail.com' ,'', '', '', '', '', '', '');";
?>

