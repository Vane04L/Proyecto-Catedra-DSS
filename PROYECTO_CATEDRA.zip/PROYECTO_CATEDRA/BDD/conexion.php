<?php
$host = 'localhost'; //vane aqui el nombre del servidor de la base de datos
$user = 'root'; //nombre de usuario de la base de datos
$password = ''; //contraseña de la base de datos
$dbname = 'proyecto_catedra_php'; //nombre de la base de datos

$mysqli = mysqli_connect($host, $user, $password, $dbname);

// Verificar la conexión
if (!$mysqli) {
    die("La conexión falló: " . mysqli_connect_error());
}

