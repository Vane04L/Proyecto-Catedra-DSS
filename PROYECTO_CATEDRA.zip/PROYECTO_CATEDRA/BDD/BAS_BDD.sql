CREATE TABLE USUARIO(
    id_US INT AUTO_INCREMENT,
    Correo_US char(60) NOT NULL,
    Nombre_US char(40) NOT NULL,
    Apellidos_US char(40) NOT NULL,
    DUI_US char(10) NOT NULL,
    Telefono_US int(8) NOT NULL,
    Nombre_trabajo_US char(100) NOT NULL,
    Salario_US int(10) NOT NULL,
    Numero_cuentas_US int(1) NULL,
    PRIMARY KEY (id_US)
) ENGINE = InnoDB DEFAULT CHARSET = latin1;

CREATE TABLE CUENTA(
    id_cuenta_CU INT AUTO_INCREMENT,
    id_usuario_US INT NOT NULL,
    Identificacion_CU CHAR(13) not null,
    Tipo_cuenta_CU INT not null,
    Activa_CU bit not null,
    Password_CU text not null,
    dinero_CU DECIMAL(10,2),
    PRIMARY KEY (id_cuenta_CU),
    KEY CUENTA_USUARIOS (id_usuario_US)
) ENGINE = InnoDB DEFAULT CHARSET = latin1;

ALTER TABLE
    CUENTA
ADD
    CONSTRAINT CUENTA_USUARIOS FOREIGN KEY (id_usuario_US) REFERENCES USUARIO (id_US);

CREATE TABLE LISTA_MOVIMIENTO(
    id_lista_LIMO int not null,
    id_cuenta_CU int not null,
    Cantidad_LIMO int not null,
    Fecha_LIMO char(20) not null,
    Destinatario_CU int null,
    Transacción_LIMO int not null,
    Comision_LIMO int not null,
    PRIMARY KEY (id_lista_LIMO),
    KEY LISTA_MOVIMIENTO_CUENTA (id_cuenta_CU),
    KEY LISTA_MOVIMIENTO_CUENTA2 (Destinatario_CU)
) ENGINE = InnoDB DEFAULT CHARSET = latin1;

ALTER TABLE
    LISTA_MOVIMIENTO
ADD
    CONSTRAINT LISTA_MOVIMIENTO_CUENTA FOREIGN KEY (id_cuenta_CU) REFERENCES CUENTA (id_cuenta_CU),
ADD
    CONSTRAINT LISTA_MOVIMIENTO_CUENTA2 FOREIGN KEY (Destinatario_CU) REFERENCES CUENTA (id_cuenta_CU);

CREATE TABLE PRESTAMO(
    id_prestamo_PR int not null,
    usuario_CU int not null,
    Monto_PR int not null,
    Estado_PR bit not null,
    cuota_PR int not null,
    PLazo_PR int not null,
    Taza_interes_PR int not null,
    PRIMARY KEY (id_prestamo_PR),
    KEY PRESTAMO_CUENTA (usuario_CU)
) ENGINE = InnoDB DEFAULT CHARSET = latin1;

ALTER TABLE
    PRESTAMO
ADD
    CONSTRAINT PRESTAMO_CUENTA FOREIGN KEY (usuario_CU) REFERENCES CUENTA (id_cuenta_CU);

-- -- INSERTAR
-- INSERT INTO
--     `usuario` (
--         `id_US`,
--         `Correo_US`,
--         `Nombre_US`,
--         `Apellidos_US`,
--         `DUI_US`,
--         `Telefono_US`,
--         `Nombre_trabajo_US`,
--         `Salario_US`,
--         `Numero_cuentas_US`
--     )
-- VALUES
--     (
--         `1`,
--         `Jonnathanweltx@gmail.com`,
--         `Jonnathan Alexander`,
--         `Urquilla Munoz`,
--         `06325073-2`,
--         `72963923`,
--         `MAC DONALS `,
--         ` 300 `,
--         ` 0 `
--     ),
--     ('2', 'Vannesa@gmail.com', 'Vannesa Alexandra', 'Urquilla Munoz', '12345678-0', '72963923', 'DON POLLO', '200', '0');


CREATE TABLE usuarios(
    id_usuario INT(11) AUTO_INCREMENT,
    nombres char(60) NOT NULL,
    apellidos char(60) NOT NULL,
    id_departamento int NOT NULL,
    id_tipousuario int NOT NULL,
    usuario varchar(11) NOT NULL,
    contrasenia varchar(64) NOT NULL,
    PRIMARY KEY (id_usuario),
    KEY DEPARTAMENTO (id_departamento),
    KEY TIPO_USUARIO (id_tipousuario)
) ENGINE = InnoDB DEFAULT CHARSET = latin1;

CREATE TABLE tipo_usuario(
    id_tipousuario INT AUTO_INCREMENT,
    tipo_usuario varchar(80) NOT NULL,
    PRIMARY KEY (id_tipousuario)
) ENGINE = InnoDB DEFAULT CHARSET = latin1;

CREATE TABLE departamento(
    id_departamento INT AUTO_INCREMENT,
    departamento varchar(80) NOT NULL,
    PRIMARY KEY (id_departamento)
) ENGINE = InnoDB DEFAULT CHARSET = latin1;

ALTER TABLE
    usuarios
ADD
    CONSTRAINT DEPARTAMENTO FOREIGN KEY (id_departamento) REFERENCES departamento (id_departamento),
    CONSTRAINT TIPO_USUARIO FOREIGN KEY (id_tipousuario) REFERENCES tipo_usuario (id_tipousuario);