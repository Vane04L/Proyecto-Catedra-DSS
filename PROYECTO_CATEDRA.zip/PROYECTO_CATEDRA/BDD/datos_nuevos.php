<?php
include_once 'conexion.php';


function nuevo_usuarios($mysqli, $sql)
{
    $id_registro = '';
    if (mysqli_query($mysqli, $sql)) {
        echo "Registro insertado correctamente";
        $id_registro = mysqli_insert_id($mysqli);
    } else {
        echo "Error al insertar registro: " . mysqli_error($mysqli);
    }

    return $id_registro;
}

function nueva_cuenta($mysqli, $sql)
{
    $confirmacion = false;
    if (mysqli_query($mysqli, $sql)) {
        echo "Registro insertado correctamente";
        $confirmacion = true;
    } else {
        echo "Error al insertar registro: " . mysqli_error($mysqli);
    }

    return $confirmacion;
}

function consultar_retiros($mysqli, $sql, $numero_tabla)
{
    // echo $sql;
    $resultado = mysqli_query($mysqli, $sql);
    $contador = 1;
    while ($fila = mysqli_fetch_assoc($resultado)) {
        $Fecha_LIMO = $fila["Fecha_LIMO"];
        $Cantidad_LIMO = number_format($fila["Cantidad_LIMO"], 2, '.', '');
        $Comision_LIMO = number_format($fila["Comision_LIMO"], 2, '.', '');
        $Destinatario_CU = $fila["Destinatario_CU"];
        $Identificacion_CU = $fila["Identificacion_CU"];

        echo '<tr>
            <th scope="row">' . $contador . '</th>
            <td>' . $Fecha_LIMO . '</td>
            <td>$' . $Cantidad_LIMO . '</td>
            <td>$' . $Comision_LIMO . '</td>
            ';
        if ($Destinatario_CU > 0) {
            echo '<td>' . $Identificacion_CU . '</td>';
        }
        echo '</tr>';
        $contador++;
    }

    $si = mysqli_num_rows($resultado) > 0;

    if ($si) {
    } else {
        echo '<tr>';
        if ($numero_tabla == 5) {
            echo '<td colspan="5">NO HAY REGISTROS</td>';
        } else {
            echo '<td colspan="4">NO HAY REGISTROS</td>';
        }

        echo '<tr>';
    }
}

function consultar_n_cuentas($mysqli, $sql)
{
    $resultado = mysqli_query($mysqli, $sql);
    $dato = false;
    $si = mysqli_num_rows($resultado) > 0 && mysqli_num_rows($resultado) <= 2;

    echo $si;
    if ($si) {
        $dato = true;
    }

    return $dato;
}

function saber_usuario($mysqli, $sql)
{
    $resultado = mysqli_query($mysqli, $sql);
    $dato = '';
    while ($fila = mysqli_fetch_assoc($resultado)) {
        $id_US = $fila["id_US"];
    }

    $si = mysqli_num_rows($resultado) > 0;
    if ($si) {
        $dato = $id_US;
    }
    return $dato;
}
