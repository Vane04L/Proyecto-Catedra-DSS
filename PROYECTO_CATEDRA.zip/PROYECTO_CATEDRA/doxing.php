<?php
// Escript para obtenet IP y Ubicación gegrafica!. 

//Jajajaj borre el escript vane :V ya que esto no debia estar aquí
?>
