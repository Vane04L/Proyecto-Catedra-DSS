-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1:3306
-- Tiempo de generación: 10-05-2023 a las 05:15:53
-- Versión del servidor: 8.0.31
-- Versión de PHP: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `proyecto_catedra_php`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cuenta`
--

DROP TABLE IF EXISTS `cuenta`;
CREATE TABLE IF NOT EXISTS `cuenta` (
  `id_cuenta_CU` int NOT NULL AUTO_INCREMENT,
  `id_usuario_US` int NOT NULL,
  `Identificacion_CU` char(13) NOT NULL,
  `Tipo_cuenta_CU` int NOT NULL,
  `Activa_CU` bit(1) NOT NULL,
  `Password_CU` text NOT NULL,
  `dinero_CU` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id_cuenta_CU`),
  KEY `CUENTA_USUARIOS` (`id_usuario_US`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `cuenta`
--

INSERT INTO `cuenta` (`id_cuenta_CU`, `id_usuario_US`, `Identificacion_CU`, `Tipo_cuenta_CU`, `Activa_CU`, `Password_CU`, `dinero_CU`) VALUES
(1, 1, 'BAS-2155-6817', 1, b'1', '$2y$10$LyNafUg6ubbyhp9XNFPp..0ArFcajnJhsnZHqzPsIZWSvw0b0mLwW', '2680.00'),
(2, 2, 'BAS-4543-2233', 1, b'1', '$2y$10$wXeVeZZ1UVEsNbyqbmqr7e4GAh/OWc4WY0ShhXbW3aJ8xcs5SI9yG', '730.00'),
(3, 5, 'BAS-5688-5799', 2, b'1', '$2y$10$1u98BxancKmlfa3jFUkzEeuPT9Dk7jGrWqHUJRM36AKOVVVLKpDbe', '0.00'),
(4, 7, 'BAS-1136-7963', 1, b'1', '$2y$10$2K745U7JAaql/dKE30VHi.hSA0V/tLMoBubAA/Bf15e9rcYE3i0XK', '0.00'),
(5, 8, 'BAS-8477-8690', 1, b'1', '$2y$10$C5Z6zHMsMvG17B/E3gnGuOFOXqP7sNhVveyJIgYep2NZUJqtvnFPG', '-2100.00'),
(6, 7, 'BAS-7543-3468', 1, b'1', '$2y$10$eERvrLtKrCqopiEkmeeUAeOEXZaee2TZd/EYwUjzHXJUkWo4pC5.i', '-40.00'),
(7, 7, 'BAS-1870-7560', 1, b'1', '$2y$10$AxujD6Gouxgi.lb/2uVjt.DHldrI3oPO6GzCSCLPX.VlZkcbfhQtu', '-20.17'),
(8, 9, 'BAS-2513-8834', 3, b'1', '$2y$10$t6SSGudt4EWOH//WNttKueZ/xU4t49bkFZ0V1PjrZFdwlzUFQQSVe', '0.00'),
(9, 10, 'BAS-7124-1537', 2, b'1', '$2y$10$oxNHUBcwVZEI.V0KWtHRJezybk.4mGQOuf6sxClnGNPHeKLegSju2', '0.00');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `lista_movimiento`
--

DROP TABLE IF EXISTS `lista_movimiento`;
CREATE TABLE IF NOT EXISTS `lista_movimiento` (
  `id_lista_LIMO` int NOT NULL AUTO_INCREMENT,
  `id_cuenta_CU` int NOT NULL,
  `Cantidad_LIMO` int NOT NULL,
  `Fecha_LIMO` char(20) NOT NULL,
  `Destinatario_CU` int DEFAULT NULL,
  `Transacción_LIMO` int NOT NULL,
  `Comision_LIMO` int NOT NULL,
  PRIMARY KEY (`id_lista_LIMO`),
  KEY `LISTA_MOVIMIENTO_CUENTA` (`id_cuenta_CU`),
  KEY `LISTA_MOVIMIENTO_CUENTA2` (`Destinatario_CU`)
) ENGINE=InnoDB AUTO_INCREMENT=110 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `lista_movimiento`
--

INSERT INTO `lista_movimiento` (`id_lista_LIMO`, `id_cuenta_CU`, `Cantidad_LIMO`, `Fecha_LIMO`, `Destinatario_CU`, `Transacción_LIMO`, `Comision_LIMO`) VALUES
(1, 1, 300, '05/12/2022', 2, 39443, 0),
(2, 1, 40, '2023-05-03', 2, 3, 0),
(3, 1, 40, '2023-05-03', 2, 3, 0),
(4, 1, 40, '2023-05-03', 2, 3, 0),
(5, 1, 100, '2023-05-03', 2, 3, 0),
(6, 1, 10, '2023-05-10', 2, 3, 0),
(7, 1, 300, '05/12/2022', NULL, 1, 0),
(8, 1, 300, '05/12/2022', NULL, 1, 0),
(9, 1, 26, '2023-05-09', NULL, 1, 0),
(10, 1, 26, '2023-05-09', NULL, 1, 0),
(11, 1, 26, '2023-05-09', NULL, 1, 0),
(12, 1, 300, '2023-05-09', NULL, 1, 0),
(13, 1, 300, '2023-05-09', NULL, 1, 0),
(14, 1, 300, '2023-05-09', NULL, 1, 0),
(15, 1, 300, '2023-05-09', NULL, 1, 0),
(16, 1, 300, '2023-05-09', NULL, 1, 0),
(17, 1, 300, '2023-05-09', NULL, 1, 0),
(18, 1, 300, '2023-05-09', NULL, 1, 0),
(19, 1, 300, '2023-05-09', NULL, 1, 0),
(20, 1, 300, '2023-05-09', NULL, 1, 0),
(21, 1, 300, '2023-05-09', NULL, 1, 0),
(22, 1, 300, '2023-05-09', NULL, 1, 0),
(23, 1, 300, '2023-05-09', NULL, 1, 0),
(24, 1, 300, '2023-05-09', NULL, 1, 0),
(25, 1, 300, '2023-05-09', NULL, 1, 0),
(26, 1, 300, '2023-05-09', NULL, 1, 0),
(27, 1, 300, '2023-05-09', NULL, 1, 0),
(28, 1, 300, '2023-05-09', NULL, 1, 0),
(29, 1, 300, '2023-05-09', NULL, 1, 0),
(30, 1, 300, '2023-05-09', NULL, 1, 0),
(31, 1, 300, '2023-05-09', NULL, 1, 0),
(32, 1, 300, '2023-05-09', NULL, 1, 0),
(33, 1, 300, '2023-05-09', NULL, 1, 0),
(34, 1, 300, '2023-05-09', NULL, 1, 0),
(35, 1, 300, '2023-05-09', NULL, 1, 0),
(36, 1, 300, '2023-05-09', NULL, 1, 0),
(37, 1, 300, '2023-05-09', NULL, 1, 0),
(38, 1, 300, '2023-05-09', NULL, 1, 0),
(39, 1, 300, '2023-05-09', NULL, 1, 0),
(40, 1, 300, '2023-05-09', NULL, 1, 0),
(41, 1, 300, '2023-05-09', NULL, 1, 0),
(42, 1, 300, '2023-05-09', NULL, 1, 0),
(43, 1, 300, '2023-05-09', NULL, 1, 0),
(44, 1, 300, '2023-05-09', NULL, 1, 0),
(45, 1, 300, '2023-05-09', NULL, 1, 0),
(46, 1, 300, '2023-05-09', NULL, 1, 0),
(47, 1, 300, '2023-05-09', NULL, 1, 0),
(48, 1, 300, '2023-05-09', NULL, 1, 0),
(49, 1, 300, '2023-05-09', NULL, 1, 0),
(50, 1, 300, '2023-05-09', NULL, 1, 0),
(51, 1, 300, '2023-05-09', NULL, 1, 0),
(52, 1, 300, '2023-05-09', NULL, 1, 0),
(53, 1, 300, '2023-05-09', NULL, 1, 0),
(54, 1, 300, '2023-05-09', NULL, 1, 0),
(55, 1, 300, '2023-05-09', NULL, 1, 0),
(56, 1, 300, '2023-05-09', NULL, 1, 0),
(57, 1, 300, '2023-05-09', NULL, 1, 0),
(58, 1, 300, '2023-05-09', NULL, 1, 0),
(59, 1, 300, '2023-05-09', NULL, 1, 0),
(60, 1, 300, '2023-05-09', NULL, 1, 0),
(61, 1, 300, '2023-05-09', NULL, 1, 0),
(62, 1, 300, '2023-05-09', NULL, 1, 0),
(63, 1, 300, '2023-05-09', NULL, 1, 0),
(64, 1, 300, '2023-05-09', NULL, 1, 0),
(65, 1, 300, '2023-05-09', NULL, 1, 0),
(66, 1, 300, '2023-05-09', NULL, 1, 0),
(67, 1, 300, '2023-05-09', NULL, 1, 0),
(68, 1, 300, '2023-05-09', NULL, 1, 0),
(69, 1, 300, '2023-05-09', NULL, 1, 0),
(70, 1, 300, '2023-05-09', NULL, 1, 0),
(71, 1, 300, '2023-05-09', NULL, 1, 0),
(72, 1, 300, '2023-05-09', NULL, 1, 0),
(73, 1, 300, '2023-05-09', NULL, 1, 0),
(74, 1, 300, '2023-05-09', NULL, 1, 0),
(75, 1, 300, '2023-05-09', NULL, 1, 0),
(76, 1, 300, '2023-05-09', NULL, 1, 0),
(77, 1, 300, '2023-05-09', NULL, 1, 0),
(78, 1, 300, '2023-05-09', NULL, 1, 0),
(79, 1, 300, '2023-05-09', NULL, 1, 0),
(80, 1, 300, '2023-05-09', NULL, 1, 0),
(81, 1, 300, '2023-05-09', NULL, 1, 0),
(82, 1, 300, '2023-05-09', NULL, 1, 0),
(83, 1, 300, '2023-05-09', NULL, 1, 0),
(84, 1, 300, '2023-05-09', NULL, 1, 0),
(85, 1, 300, '2023-05-09', NULL, 1, 0),
(86, 2, 400, '2023-05-09', NULL, 1, 0),
(87, 1, 300, '2023-05-09', NULL, 1, 0),
(88, 1, 300, '2023-05-09', NULL, 1, 0),
(89, 1, 300, '2023-05-09', NULL, 1, 0),
(90, 1, 300, '2023-05-09', NULL, 1, 0),
(91, 1, 300, '2023-05-09', NULL, 1, 0),
(92, 1, 300, '2023-05-09', NULL, 1, 0),
(93, 1, 300, '2023-05-09', NULL, 1, 0),
(94, 1, 300, '2023-05-09', NULL, 1, 0),
(95, 1, 300, '2023-05-09', NULL, 1, 0),
(96, 1, 300, '2023-05-09', NULL, 1, 0),
(97, 1, 300, '2023-05-09', NULL, 1, 0),
(98, 1, 300, '2023-05-09', NULL, 1, 0),
(99, 2, 400, '2023-05-09', NULL, 1, 0),
(100, 2, 400, '2023-05-09', NULL, 1, 0),
(101, 2, 20, '2023-05-17', 1, 3, 0),
(102, 1, 20, '2023-05-25', 3, 3, 0),
(103, 7, 20, '2023-05-09', NULL, 1, 0),
(104, 6, 40, '2023-05-09', NULL, 1, 0),
(105, 1, 300, '2023-05-09', NULL, 1, 0),
(106, 5, 400, '2023-05-09', NULL, 1, 0),
(107, 5, 400, '2023-05-09', NULL, 1, 0),
(108, 5, 400, '2023-05-09', NULL, 1, 0),
(109, 5, 900, '2023-05-09', NULL, 1, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2023_05_09_202757_create_cuentas_table', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
CREATE TABLE IF NOT EXISTS `personal_access_tokens` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `prestamo`
--

DROP TABLE IF EXISTS `prestamo`;
CREATE TABLE IF NOT EXISTS `prestamo` (
  `id_prestamo_PR` int NOT NULL AUTO_INCREMENT,
  `usuario_CU` int NOT NULL,
  `Monto_PR` float NOT NULL,
  `Estado_PR` bit(1) DEFAULT NULL,
  `cuota_PR` float NOT NULL,
  `PLazo_PR` float NOT NULL,
  `Taza_interes_PR` float NOT NULL,
  PRIMARY KEY (`id_prestamo_PR`),
  KEY `PRESTAMO_CUENTA` (`usuario_CU`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `prestamo`
--

INSERT INTO `prestamo` (`id_prestamo_PR`, `usuario_CU`, `Monto_PR`, `Estado_PR`, `cuota_PR`, `PLazo_PR`, `Taza_interes_PR`) VALUES
(1, 1, 10000, b'1', 90, 0, 0),
(2, 2, 20000, b'0', 80, 0.03, 0.077),
(3, 2, 1000, b'0', 10, 0.03, 0.05),
(4, 1, 9000, b'1', 80, 0.03, 0.053),
(5, 5, 23565, b'1', 270, 0.04, 0.054);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

DROP TABLE IF EXISTS `usuario`;
CREATE TABLE IF NOT EXISTS `usuario` (
  `id_US` int NOT NULL AUTO_INCREMENT,
  `Correo_US` char(60) NOT NULL,
  `Nombre_US` char(40) NOT NULL,
  `Apellidos_US` char(40) NOT NULL,
  `DUI_US` char(10) NOT NULL,
  `Telefono_US` int NOT NULL,
  `Nombre_trabajo_US` char(100) NOT NULL,
  `Salario_US` int NOT NULL,
  `Numero_cuentas_US` int DEFAULT NULL,
  PRIMARY KEY (`id_US`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`id_US`, `Correo_US`, `Nombre_US`, `Apellidos_US`, `DUI_US`, `Telefono_US`, `Nombre_trabajo_US`, `Salario_US`, `Numero_cuentas_US`) VALUES
(1, 'nazi@gmail.com', 'Jocelyn', 'alvarado', '12345678-0', 1234, 'diegop0y0', 300, 1),
(2, 'hernandez@gmail.com', 'jose hernandez', 'guitieres', '12345678-9', 7296, 'WELTX', 400, 1),
(3, 'Jonnathanweltx1@gmail.com', 'Alexander', 'Urquilla Munoz', '12345678-1', 72963923, 'DON POLLO', 400, 2),
(4, 'nicol@gmail.com', 'nicol alexandra', 'perez perez', '12345678-2', 72963923, 'banco', 400, 3),
(5, 'Vannesa@gmail.com', 'Vannesa', 'Alvarado', '12345678-4', 7296, 'BODEGA DE MAYONESA', 600, 2),
(6, 'Javier@gmail.com', 'Javier', 'hernandez', '12345678-5', 72963923, 'BANCO', 600, 3),
(7, 'jose@gmail.com', 'jose alexander', 'perez perez', '12345678-6', 7296, 'UDB', 400, 1),
(8, 'alvarado@gmail.com', 'alvarado alexander', 'perez perez', '12345678-7', 7271, 'UBD SOYA', 900, 1),
(9, 'donbosco@gmail.com', 'don bosco', 'udb', '12345678-8', 1234, 'UDB SOYAPANGO', 600, 3),
(10, 'prueba@gmail.com', 'prueba dependiente', 'prueba prueba', '12345679-1', 7296, 'PANADERIA LUZ DE DIOS', 600, 2);

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `cuenta`
--
ALTER TABLE `cuenta`
  ADD CONSTRAINT `CUENTA_USUARIOS` FOREIGN KEY (`id_usuario_US`) REFERENCES `usuario` (`id_US`);

--
-- Filtros para la tabla `lista_movimiento`
--
ALTER TABLE `lista_movimiento`
  ADD CONSTRAINT `LISTA_MOVIMIENTO_CUENTA` FOREIGN KEY (`id_cuenta_CU`) REFERENCES `cuenta` (`id_cuenta_CU`),
  ADD CONSTRAINT `LISTA_MOVIMIENTO_CUENTA2` FOREIGN KEY (`Destinatario_CU`) REFERENCES `cuenta` (`id_cuenta_CU`);

--
-- Filtros para la tabla `prestamo`
--
ALTER TABLE `prestamo`
  ADD CONSTRAINT `PRESTAMO_CUENTA` FOREIGN KEY (`usuario_CU`) REFERENCES `cuenta` (`id_cuenta_CU`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
